const photoInput = document.querySelector("#photoInput");
const uploadZone = document.querySelector("#uploadZone");
const uploadMessage = document.querySelector("#uploadMessage");
const generateButton = document.querySelector("#generateButton");
const generationStatus = document.querySelector("#generationStatus");
const colourNameEl = document.querySelector("#colourName");
const selectedHexEl = document.querySelector("#selectedHex");
const colourPreview = document.querySelector("#colourPreview");
const finishSelect = document.querySelector("#finishSelect");
const summaryColour = document.querySelector("#summaryColour");
const summaryFinish = document.querySelector("#summaryFinish");
const emptyPreview = document.querySelector("#emptyPreview");
const comparison = document.querySelector("#comparison");
const resultImage = document.querySelector("#resultImage");
const toggleOriginal = document.querySelector("#toggleOriginal");
const downloadPreview = document.querySelector("#downloadPreview");
const quoteForm = document.querySelector("#quoteForm");
const quoteButton = document.querySelector("#quoteButton");
const quoteStatus = document.querySelector("#quoteStatus");

let originalDataUrl = "";
let previewDataUrl = "";
let selectedColour = { name: "Warm Ivory", hex: "#E9E1D3" };
let showingOriginal = false;

function setStatus(element, message, type = "") {
  element.textContent = message;
  element.className = `status${type ? ` ${type}` : ""}`;
}
function setUploadMessage(message) { uploadMessage.textContent = message; }

function updateSelection() {
  colourNameEl.textContent = selectedColour.name;
  selectedHexEl.textContent = selectedColour.hex;
  colourPreview.style.background = selectedColour.hex;
  summaryColour.textContent = selectedColour.name;
  summaryFinish.textContent = finishSelect.value;
}
document.querySelectorAll(".swatch").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".swatch").forEach((item) => {
      item.classList.remove("selected");
      item.setAttribute("aria-checked", "false");
    });
    button.classList.add("selected");
    button.setAttribute("aria-checked", "true");
    selectedColour = { name: button.dataset.name, hex: button.dataset.hex };
    updateSelection();
  });
});
finishSelect.addEventListener("change", updateSelection);

function readFileAsImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => { URL.revokeObjectURL(url); resolve(image); };
    image.onerror = () => { URL.revokeObjectURL(url); reject(new Error("This image could not be opened. Please try another photo.")); };
    image.src = url;
  });
}

// Compress the upload in the browser so the JSON request stays below typical Vercel
// Function request-body limits. The original file is never sent directly.
async function compressPhoto(file) {
  const allowed = ["image/jpeg", "image/png", "image/webp"];
  if (!allowed.includes(file.type)) throw new Error("Please upload a JPG, PNG or WebP image.");
  if (file.size > 12 * 1024 * 1024) throw new Error("The photo must be smaller than 12 MB.");
  const image = await readFileAsImage(file);
  const maxSide = 1536;
  const scale = Math.min(1, maxSide / Math.max(image.naturalWidth, image.naturalHeight));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
  canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
  const context = canvas.getContext("2d", { alpha: false });
  context.fillStyle = "#ffffff";
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.drawImage(image, 0, 0, canvas.width, canvas.height);
  let quality = 0.84;
  let dataUrl = canvas.toDataURL("image/jpeg", quality);
  while (dataUrl.length > 3_350_000 && quality > 0.48) {
    quality -= 0.08;
    dataUrl = canvas.toDataURL("image/jpeg", quality);
  }
  if (dataUrl.length > 3_350_000) throw new Error("This photo is still too large after compression. Please try a smaller image.");
  return dataUrl;
}

async function handlePhoto(file) {
  if (!file) return;
  try {
    setUploadMessage("Preparing photo…");
    generateButton.disabled = true;
    originalDataUrl = await compressPhoto(file);
    previewDataUrl = "";
    resultImage.removeAttribute("src");
    comparison.classList.add("hidden");
    emptyPreview.classList.remove("hidden");
    emptyPreview.querySelector("strong").textContent = "Photo ready to transform";
    emptyPreview.querySelector("p").textContent = "Choose your colour and finish, then generate your preview.";
    setUploadMessage(`Photo ready · ${Math.round(originalDataUrl.length * 0.75 / 1024)} KB compressed`);
    setStatus(generationStatus, "");
    generateButton.disabled = false;
    showingOriginal = false;
    toggleOriginal.textContent = "View original";
  } catch (error) {
    originalDataUrl = "";
    setUploadMessage(error.message);
    generateButton.disabled = true;
  }
}
photoInput.addEventListener("change", () => handlePhoto(photoInput.files?.[0]));
["dragenter", "dragover"].forEach(type => uploadZone.addEventListener(type, event => {
  event.preventDefault(); uploadZone.classList.add("dragging");
}));
["dragleave", "drop"].forEach(type => uploadZone.addEventListener(type, event => {
  event.preventDefault(); uploadZone.classList.remove("dragging");
}));
uploadZone.addEventListener("drop", event => {
  const file = event.dataTransfer?.files?.[0];
  if (file) handlePhoto(file);
});

generateButton.addEventListener("click", async () => {
  if (!originalDataUrl) return;
  generateButton.disabled = true;
  generateButton.querySelector(".button-label").textContent = "Creating preview…";
  setStatus(generationStatus, "AI is working on your room. This may take a little while.");
  try {
    const response = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        imageDataUrl: originalDataUrl,
        colourName: selectedColour.name,
        colourHex: selectedColour.hex,
        finish: finishSelect.value
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "Preview generation failed. Please try again.");
    if (!data.imageDataUrl) throw new Error("The AI service returned no preview image.");
    previewDataUrl = data.imageDataUrl;
    resultImage.src = previewDataUrl;
    downloadPreview.href = previewDataUrl;
    downloadPreview.download = "classy-coat-paint-preview.jpg";
    showingOriginal = false;
    resultImage.src = previewDataUrl;
    resultImage.alt = `AI preview with ${selectedColour.name} and ${finishSelect.value}`;
    toggleOriginal.textContent = "View original";
    emptyPreview.classList.add("hidden");
    comparison.classList.remove("hidden");
    updateSelection();
    setStatus(generationStatus, "Your preview is ready. If you like it, send it with a quotation request.", "success");
  } catch (error) {
    setStatus(generationStatus, error.message, "error");
  } finally {
    generateButton.disabled = !originalDataUrl;
    generateButton.querySelector(".button-label").textContent = "Generate my preview";
  }
});

toggleOriginal.addEventListener("click", () => {
  if (!originalDataUrl || !previewDataUrl) return;
  showingOriginal = !showingOriginal;
  resultImage.src = showingOriginal ? originalDataUrl : previewDataUrl;
  resultImage.alt = showingOriginal ? "Original uploaded room photo" : "AI-generated room paint preview";
  document.querySelector(".image-label").textContent = showingOriginal ? "ORIGINAL" : "PREVIEW";
  toggleOriginal.textContent = showingOriginal ? "View preview" : "View original";
});

quoteForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!previewDataUrl) {
    setStatus(quoteStatus, "Please generate a preview before sending your quotation request.", "error");
    return;
  }
  if (!document.querySelector("#privacyConsent").checked) return;
  quoteButton.disabled = true;
  quoteButton.textContent = "Sending request…";
  setStatus(quoteStatus, "Sending your selected preview and details to Classy Coat…");
  const payload = {
    name: document.querySelector("#customerName").value.trim(),
    contact: document.querySelector("#customerContact").value.trim(),
    propertyType: document.querySelector("#propertyType").value,
    area: document.querySelector("#propertyArea").value.trim(),
    message: document.querySelector("#customerMessage").value.trim(),
    colourName: selectedColour.name,
    colourHex: selectedColour.hex,
    finish: finishSelect.value,
    previewDataUrl
  };
  try {
    const response = await fetch("/api/quote", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "We could not send your request. Please try again.");
    setStatus(quoteStatus, "Thank you! Your quotation request and preview have been sent to Classy Coat.", "success");
    quoteForm.reset();
  } catch (error) {
    setStatus(quoteStatus, `${error.message} Please contact Classy Coat directly if this continues.`, "error");
  } finally {
    quoteButton.disabled = false;
    quoteButton.innerHTML = 'Send quotation request <span aria-hidden="true">↗</span>';
  }
});

updateSelection();
