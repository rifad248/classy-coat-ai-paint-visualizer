# Classy Coat AI Paint Visualizer — Starter Project

A custom HTML/CSS/JavaScript website with Vercel Node.js API functions. Customers upload a room photo, select a wall colour and decorative finish, generate an AI concept preview, compare it with the original and email a quotation request to Classy Coat with the preview attached.

## What is included

- Responsive frontend: `index.html`, `style.css`, `app.js`
- Secure server-side image edit endpoint: `api/generate.js`
- Quotation endpoint that emails the selected preview as an attachment: `api/quote.js`
- Environment variable template: `.env.example`

## Requirements

- Node.js 20+ recommended
- A Vercel account and a project connected to this repository/folder
- OpenAI API access and API billing configured
- A Resend account, API key and verified sender domain/address for quote emails

The image edit API model is configurable with `OPENAI_IMAGE_MODEL`. The default in this starter is `gpt-image-2.5-sunburst`. Model availability and organisation verification can vary. If your API project cannot access that model, set `OPENAI_IMAGE_MODEL` to an image-edit model available in your account.

## Run locally

1. Download and unzip the project.
2. Install Node.js if it is not already installed.
3. Open a terminal in this folder and run:

   ```bash
   npm install
   npx vercel login
   npx vercel dev
   ```

4. When Vercel CLI prompts you, link this folder to a new or existing Vercel project.
5. Add the environment variables listed below to the Vercel project. For local development, you can either add them in Vercel and run `npx vercel env pull .env.local`, or create a local `.env` file from `.env.example`. Never commit real secrets.

## Required environment variables

Add these in **Vercel Dashboard → your project → Settings → Environment Variables**:

- `OPENAI_API_KEY`: your OpenAI API key. Server-side only.
- `OPENAI_IMAGE_MODEL`: optional. Defaults to `gpt-image-2.5-sunburst`.
- `RESEND_API_KEY`: API key from Resend.
- `QUOTE_TO_EMAIL`: inbox that should receive quote requests.
- `QUOTE_FROM_EMAIL`: sender identity verified with Resend, for example `Classy Coat Visualizer <visualizer@your-domain.com>`.

After adding or changing variables, redeploy the project. Vercel documents that environment variable changes apply to new deployments, not existing deployments.

## Deploy to Vercel

### Option A — Vercel CLI

```bash
npx vercel
```

Review the preview deployment. Once tested:

```bash
npx vercel --prod
```

### Option B — Git integration

1. Push this folder to a private GitHub repository.
2. In Vercel, select **Add New → Project** and import the repository.
3. Keep the project root at the folder containing `package.json`, `index.html` and `api/`.
4. Add the environment variables listed above.
5. Deploy and test the preview URL before promoting it to production.

This is a static frontend plus Vercel Node.js functions; it does not require Next.js. The `api/` directory provides `/api/generate` and `/api/quote`.

## Add it to an existing website

The easiest route is to deploy the visualizer as a Vercel project and connect a subdomain such as `visualizer.yourdomain.com`, or deploy it under a path using a suitable Vercel rewrite/domain setup. If your existing website is hosted elsewhere, a separate Vercel subdomain is usually simpler than trying to place server functions into a static folder on the old host.

If you want it under `yourdomain.com/paint-visualizer/`, configure the domain and route/rewrite deliberately and test relative asset paths and `/api/*` endpoints. Do not simply upload the folder to static-only hosting: the API endpoints require a server runtime.

## How quotation delivery works

The browser sends the customer details and generated preview to `/api/quote`. The Vercel function sends a plain-text email through Resend and attaches the generated JPG preview. No photo gallery or permanent image storage is implemented in this starter.

For live use, verify the sender domain in Resend, set the destination inbox and test delivery. Do not use an unverified sender address.

## Important limitations and production checklist

- AI output is a visual concept, not an exact paint sample or a promise of the final physical result.
- AI may alter furniture or architectural details despite careful instructions. Test with varied room photos before launch.
- This first version does not create a precise wall segmentation mask. Add a segmentation/masking step if strict wall-only edits are required.
- This starter compresses photos in the browser and limits the request size to reduce the chance of exceeding Vercel's function body limit.
- Add production-grade rate limiting (for example, a managed rate-limit service), abuse monitoring and cost alerts before public promotion. In-memory counters are not reliable across serverless instances.
- Consider CAPTCHA/Turnstile to deter automated abuse.
- Add your business privacy policy and retention/contact details. The generated preview is only held in browser memory until the customer leaves/reloads the page; when a quote is submitted, the preview is emailed to your configured inbox.
- Do not log uploaded images, preview data URLs, customer contact details or API keys.
- Configure domain access, HTTPS, email deliverability, error monitoring and a spending limit/alert before promoting the feature.
- The visualizer does not automatically estimate quantities, paint coverage, labour costs or quote prices.

## Test checklist

1. Open the deployed site on a phone and desktop.
2. Upload a clear room JPG/PNG/WebP; check that the image is compressed.
3. Choose each colour and finish.
4. Generate a preview; check the output and the error message for a deliberately invalid API key.
5. Toggle original/preview and download the preview.
6. Submit a test quotation with consent checked.
7. Confirm the email arrives with the preview attachment.
8. Test invalid files, network failures and a mobile connection.
9. Check the browser Network tab: no OpenAI API key should ever appear in frontend requests or responses.

## API endpoints

- `POST /api/generate` — JSON `{ imageDataUrl, colourName, colourHex, finish }`
- `POST /api/quote` — JSON with customer details, selected finish and `previewDataUrl`

Both endpoints return JSON and set `Cache-Control: no-store`.
