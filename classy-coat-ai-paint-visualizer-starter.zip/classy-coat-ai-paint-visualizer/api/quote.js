export const config = { api: { bodyParser: { sizeLimit: "4mb" } } };

const MAX_PREVIEW_CHARS = 3_350_000;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function sendJson(res, status, body) {
  res.status(status).setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  return res.json(body);
}
function clean(value, max = 500) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendJson(res, 405, { error: "Method not allowed." });
  }
  const { RESEND_API_KEY, QUOTE_TO_EMAIL, QUOTE_FROM_EMAIL } = process.env;
  if (!RESEND_API_KEY || !QUOTE_TO_EMAIL || !QUOTE_FROM_EMAIL) {
    return sendJson(res, 503, {
      error: "Quotation email is not configured yet. Add RESEND_API_KEY, QUOTE_TO_EMAIL and QUOTE_FROM_EMAIL in Vercel project settings."
    });
  }

  const body = req.body || {};
  const name = clean(body.name, 100);
  const contact = clean(body.contact, 150);
  const propertyType = clean(body.propertyType, 80);
  const area = clean(body.area, 120);
  const message = clean(body.message, 1000);
  const colourName = clean(body.colourName, 60);
  const colourHex = clean(body.colourHex, 7);
  const finish = clean(body.finish, 100);
  const previewDataUrl = body.previewDataUrl;

  if (!name || !contact || !colourName || !finish) {
    return sendJson(res, 400, { error: "Please complete the required fields and generate a preview." });
  }
  if (typeof previewDataUrl !== "string" || previewDataUrl.length > MAX_PREVIEW_CHARS) {
    return sendJson(res, 413, { error: "Preview attachment is too large. Please generate a new preview." });
  }
  const match = previewDataUrl.match(/^data:image\/jpeg;base64,([A-Za-z0-9+/=]+)$/);
  if (!match) return sendJson(res, 400, { error: "The preview image is invalid. Please generate it again." });

  // Do not trust user input as HTML: send a plain-text email and a separate image attachment.
  const text = [
    "New Classy Coat Paint Visualizer quotation request",
    "",
    `Name: ${name}`,
    `Email / WhatsApp: ${contact}`,
    `Property type: ${propertyType || "Not provided"}`,
    `Area: ${area || "Not provided"}`,
    `Selected colour: ${colourName} (${colourHex})`,
    `Selected finish: ${finish}`,
    "",
    "Project details:",
    message || "Not provided",
    "",
    "The customer's AI preview is attached.",
    "Note: This is an AI concept image, not a final material/sample guarantee."
  ].join("\n");

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: QUOTE_FROM_EMAIL,
        to: [QUOTE_TO_EMAIL],
        subject: `Paint Visualizer enquiry — ${name}`,
        text,
        attachments: [{
          filename: "classy-coat-ai-paint-preview.jpg",
          content: match[1]
        }]
      })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      console.error("Quote email provider error:", response.status, result?.message || "");
      return sendJson(res, 502, { error: "The quotation email could not be delivered. Please try again or contact Classy Coat directly." });
    }
    return sendJson(res, 200, { ok: true });
  } catch (error) {
    console.error("Quote submission error:", error?.message || "unknown");
    return sendJson(res, 500, { error: "Could not send your quotation request right now. Please try again." });
  }
}
