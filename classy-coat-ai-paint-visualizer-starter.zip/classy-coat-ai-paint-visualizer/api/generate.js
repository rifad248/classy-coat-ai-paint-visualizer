import OpenAI, { toFile } from "openai";

export const config = { api: { bodyParser: { sizeLimit: "4mb" } } };

const MAX_DATA_URL_CHARS = 3_350_000;
const ALLOWED_FINISHES = new Set([
  "Smooth paint",
  "Subtle texture paint",
  "Luxury decorative plaster",
  "Polished plaster",
  "Microcement-inspired wall finish",
  "Rust-effect accent wall",
  "Rock-effect decorative finish",
]);
const COLOUR_HEX = /^#[0-9a-fA-F]{6}$/;

function sendJson(res, status, body) {
  res.status(status).setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  return res.json(body);
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return sendJson(res, 405, { error: "Method not allowed." });
  }
  if (!process.env.OPENAI_API_KEY) {
    return sendJson(res, 503, { error: "AI preview is not configured yet. Add OPENAI_API_KEY in Vercel project settings." });
  }

  try {
    const body = req.body;
    if (!body || typeof body !== "object") return sendJson(res, 400, { error: "Invalid request." });

    const { imageDataUrl, colourName, colourHex, finish } = body;
    if (typeof imageDataUrl !== "string" || imageDataUrl.length > MAX_DATA_URL_CHARS) {
      return sendJson(res, 413, { error: "Photo is too large. Please upload a smaller image." });
    }
    const match = imageDataUrl.match(/^data:image\/jpeg;base64,([A-Za-z0-9+/=]+)$/);
    if (!match) return sendJson(res, 400, { error: "Photo must be a valid JPEG image. Please upload it again." });
    if (typeof colourName !== "string" || colourName.length > 60 || !COLOUR_HEX.test(colourHex || "")) {
      return sendJson(res, 400, { error: "Please choose a valid wall colour." });
    }
    if (!ALLOWED_FINISHES.has(finish)) return sendJson(res, 400, { error: "Please choose a supported decorative finish." });

    const imageBuffer = Buffer.from(match[1], "base64");
    if (imageBuffer.length > 2_600_000) return sendJson(res, 413, { error: "Photo is too large. Please upload a smaller image." });

    const prompt = [
      "Edit the supplied photograph for a professional painting contractor's room visualizer.",
      `Selected wall colour: ${colourName} (${colourHex}).`,
      `Selected finish: ${finish}.`,
      "Apply the selected colour and finish to the intended painted wall surfaces only.",
      "Preserve the room's existing architecture, layout, camera viewpoint, ceiling, windows, doors, flooring, furniture, objects, trim and fixtures.",
      "Keep realistic lighting, shadows, perspective and reflections. Do not add, remove or rearrange furniture or decor.",
      "For a decorative finish, make the texture believable and restrained rather than exaggerated. For microcement-inspired finish, represent a visual wall finish, not a claim about actual installed material.",
      "If a wall boundary is ambiguous, make the smallest conservative change possible and avoid altering non-wall objects.",
      "Return a photorealistic concept preview. Do not add text, logos, labels or watermarks."
    ].join(" ");

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const file = await toFile(imageBuffer, "room-photo.jpg", { type: "image/jpeg" });
    const result = await client.images.edit({
      model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-sunburst",
      image: file,
      prompt,
      size: "auto",
      quality: "low",
      output_format: "jpeg",
      n: 1
    });

    const encoded = result?.data?.[0]?.b64_json;
    if (!encoded) throw new Error("The image service returned an empty result.");
    return sendJson(res, 200, { imageDataUrl: `data:image/jpeg;base64,${encoded}` });
  } catch (error) {
    console.error("Paint visualizer generation error:", error?.status || "", error?.message || "unknown");
    if (error?.status === 401) return sendJson(res, 502, { error: "The AI service rejected the API key. Check OPENAI_API_KEY in Vercel." });
    if (error?.status === 429) return sendJson(res, 429, { error: "The AI service is busy or the API usage limit has been reached. Please try again later." });
    if (error?.status === 400) return sendJson(res, 400, { error: "The image could not be processed. Try another clear JPG room photo." });
    return sendJson(res, 500, { error: "Could not create the preview right now. Please try again in a moment." });
  }
}
